// dfi_relative.js — Encoder input mode processor for Dynamic Focus Input.
//
// inlet 0: packed list [val, cc, ch] from pack i i i
// inlet 1: mode (0 = Absolute, 1 = Relative) from Encoder Mode toggle
// outlet 0: processed list [val, cc, ch] to send fc_df_cc
//
// Absolute mode (default): passes [val, cc, ch] through unchanged.
//
// Relative mode: 2's complement accumulator per CC number.
//   Each CC gets an independent accumulator initialized to 64 (mid-range).
//   delta = (val <= 63) ? val : (val - 128)
//   acc[cc] = clamp(acc[cc] + delta, 0, 127)
//   Outputs acc[cc] instead of raw val — DF Slot receives normal 0-127 range.
//
// ASSUMED: Push 3 encoders (8 pads) transmit CC71-78 on MIDI channel 1 in
// relative 2's complement format: values 1-63 = clockwise (+), 64-127 = CCW
// (magnitude = val - 128). This assumption is based on the official Push 2
// specification and community reports for Push 3, but has NOT been verified
// via raw MIDI sniff on actual Push 3 hardware. Verify before marking
// "officially supports Push" in marketing materials.
//
// The accumulator logic is CC-number-agnostic — any relative encoder using
// 2's complement on any CC number works correctly in Relative mode.

inlets  = 2;
outlets = 1;

var _rel_mode = -1; // -1 = uninitialized (lazy init on first CC)
var _acc = {};      // per-CC accumulator: { cc_number: 0-127 }

function _ensureMode() {
    if (_rel_mode >= 0) return;
    // Lazy init: read stored value from the Encoder Mode toggle button.
    // Handles edge case where M4L parameter restore fires before JS is ready.
    var btn = patcher.getnamed("dfi_rel_btn");
    _rel_mode = btn ? Math.round(btn.getvalueof()) : 0;
}
_ensureMode.local = 1;

function list(val, cc, ch) {
    if (inlet !== 0) return;
    _ensureMode();

    if (_rel_mode === 0) {
        // Absolute mode: pass through unchanged
        outlet(0, val, cc, ch);
        return;
    }

    // Relative mode: 2's complement delta accumulation
    var delta = (val <= 63) ? val : (val - 128);
    if (_acc[cc] === undefined) {
        _acc[cc] = 64; // initialize to mid-range on first use
    }
    _acc[cc] = Math.max(0, Math.min(127, _acc[cc] + delta));
    outlet(0, _acc[cc], cc, ch);
}

function msg_int(n) {
    if (inlet !== 1) return;
    var newMode = n ? 1 : 0;
    if (newMode === _rel_mode) return; // no change
    _rel_mode = newMode;
    if (_rel_mode === 0) {
        _acc = {}; // clear accumulators when switching back to Absolute
    }
}
