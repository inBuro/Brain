// monitor_init.js — Monitor=In auto-setup for DF Input.
// Fires on live.thisdevice bang (device load).
// Fresh drop (InitF=0): sets track Monitor to In, writes InitF=1.
// .als reload (InitF=1): skips.
inlets = 1;
outlets = 0;

var _pid = -1;

function bang() {
    var t = new Task(function() {
        if (_pid <= 0) findPid();
        if (_pid <= 0) {
            post("DFI monitor_init: InitF param not found\n");
            return;
        }
        var v = 0;
        try {
            v = Math.round(parseFloat(new LiveAPI(null, "id " + _pid).get("value")));
        } catch(e) {
            post("DFI monitor_init: failed to read InitF value\n");
            return;
        }
        post("DFI monitor_init: InitF=" + v + "\n");
        if (v === 1) {
            post("DFI monitor_init: reload detected, skip\n");
            return;
        }
        var dev = new LiveAPI(null, "this_device");
        var parent = dev.get("canonical_parent");
        if (!parent || parent.length < 2) {
            post("DFI monitor_init: no canonical_parent\n");
            return;
        }
        var track = new LiveAPI(null, "id " + parent[1]);
        try {
            track.set("current_monitoring_state", 0);
            post("DFI monitor_init: set Monitor=In on track id " + parent[1] + "\n");
        } catch(e) {
            post("DFI monitor_init: failed to set monitoring\n");
        }
        try {
            new LiveAPI(null, "id " + _pid).set("value", 1);
            post("DFI monitor_init: wrote InitF=1\n");
        } catch(e) {
            post("DFI monitor_init: failed to write InitF\n");
        }
    }, this);
    t.schedule(500);
}

function findPid() {
    _pid = -1;
    try {
        var d = new LiveAPI(null, "this_device");
        var p = d.get("parameters");
        for (var i = 0; i < p.length; i++) {
            if (p[i] !== "id") continue;
            var pid = parseInt(p[i + 1], 10);
            if (pid <= 0) continue;
            var par = new LiveAPI(null, "id " + pid);
            var n = String(par.get("name"));
            if (n === "InitF" || n === "Init Flag") {
                _pid = pid;
                post("DFI monitor_init: found InitF pid=" + _pid + "\n");
                return;
            }
        }
        post("DFI monitor_init: InitF not found in parameters\n");
    } catch(e) {}
}
findPid.local = 1;
