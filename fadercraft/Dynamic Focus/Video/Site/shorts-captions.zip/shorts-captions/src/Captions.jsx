import React from 'react';
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  interpolateColors,
} from 'remotion';
import {buildPages, activePageIndex, smoothstep} from './lib.js';

// ---- The look. Tweak these values to taste. ----
const COLOR_INACTIVE = '#B7BBC2'; // light gray (unspoken + already-spoken)
const COLOR_ACTIVE = '#FFFFFF'; // white (currently spoken word)
const ACTIVE_SCALE = 1.06; // subtle scale-up on the active word (1 = off)
const FONT_SIZE = 66;
const OPACITY_FUTURE = 0.4; // not-yet-spoken words are dimmer/more transparent
const OPACITY_SPOKEN = 1.0; // already-spoken words are full gray
// System-first: on macOS this resolves to SF Pro (the Apple look) with no network/font load.
// To pin Inter/SF Pro exactly, drop a .ttf in public/ and load it with @remotion/fonts.
const fontFamily =
  '"SF Pro Display", -apple-system, "Inter", system-ui, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';

export const Captions = ({
  captions,
  maxWords = 5,
  bottomOffset = 440, // px from the bottom of a 1920-tall frame (sits in the subtitle safe zone)
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const nowMs = (frame / fps) * 1000;

  const pages = buildPages(captions, {maxWords});
  if (pages.length === 0) return null;
  const page = pages[activePageIndex(pages, nowMs)];

  // Whole-line: subtle fade + tiny rise when it appears. No bounce.
  const appear = smoothstep(
    interpolate(nowMs, [page.startMs - 130, page.startMs + 110], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    })
  );
  const lineTranslateY = interpolate(appear, [0, 1], [10, 0]);

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: bottomOffset,
          margin: '0 auto',
          maxWidth: 820, // keep lines inside the safe zone (clear of the right action rail)
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignItems: 'flex-end',
          gap: '2px 18px',
          opacity: appear,
          transform: `translateY(${lineTranslateY}px)`,
        }}
      >
        {page.words.map((w, i) => {
          // "activeness" bell around the word's spoken window.
          const inRamp = interpolate(nowMs, [w.startMs - 90, w.startMs + 60], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          const outRamp = interpolate(nowMs, [w.endMs - 20, w.endMs + 150], [1, 0], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          const act = smoothstep(Math.min(inRamp, outRamp));

          // future (not yet spoken) -> dim; once reached -> full; active -> lifts to 1
          const spoken = interpolate(nowMs, [w.startMs - 150, w.startMs - 10], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          });
          const base = OPACITY_FUTURE + (OPACITY_SPOKEN - OPACITY_FUTURE) * smoothstep(spoken);
          const opacity = base + (1 - base) * act;

          const color = interpolateColors(act, [0, 1], [COLOR_INACTIVE, COLOR_ACTIVE]);
          const scale = 1 + (ACTIVE_SCALE - 1) * act;

          return (
            <span
              key={i}
              style={{
                fontFamily,
                fontWeight: 800,
                fontSize: FONT_SIZE,
                lineHeight: 1.15,
                letterSpacing: '-0.02em',
                color,
                opacity,
                display: 'inline-block',
                transform: `scale(${scale})`,
                transformOrigin: 'center bottom',
                textShadow: '0 2px 18px rgba(0,0,0,0.35)',
                WebkitFontSmoothing: 'antialiased',
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
