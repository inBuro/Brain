// Group flat word tokens ({text, startMs, endMs}) into short lines/pages.
// Break on a max word count OR on a noticeable pause between words.
export function buildPages(captions, {maxWords = 5, gapMs = 700} = {}) {
  const pages = [];
  let cur = [];
  for (let i = 0; i < captions.length; i++) {
    const w = captions[i];
    const prev = captions[i - 1];
    const bigGap = prev && w.startMs - prev.endMs > gapMs;
    if (cur.length && (cur.length >= maxWords || bigGap)) {
      pages.push(makePage(cur));
      cur = [];
    }
    cur.push(w);
  }
  if (cur.length) pages.push(makePage(cur));
  return pages;
}

function makePage(words) {
  return {
    words,
    startMs: words[0].startMs,
    endMs: words[words.length - 1].endMs,
  };
}

// Which page is on screen at time `nowMs`: the latest page that has started.
export function activePageIndex(pages, nowMs) {
  let idx = 0;
  for (let i = 0; i < pages.length; i++) {
    if (pages[i].startMs <= nowMs) idx = i;
  }
  return idx;
}

export const smoothstep = (t) => t * t * (3 - 2 * t);
