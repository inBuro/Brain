import React from 'react';
import {Composition, AbsoluteFill, OffthreadVideo, staticFile} from 'remotion';
import {Captions} from './Captions.jsx';
import captions from './captions.json';

const FPS = 30;
const WIDTH = 1080;
const HEIGHT = 1920;

const durationFrames = (caps) => {
  const lastMs = caps.length ? caps[caps.length - 1].endMs : 3000;
  return Math.ceil((lastMs / 1000 + 0.8) * FPS);
};

// Captions burned over YOUR exported video (put it at public/video.mp4).
const CaptionedVideo = ({captions}) => (
  <AbsoluteFill style={{backgroundColor: 'black'}}>
    <OffthreadVideo src={staticFile('video.mp4')} />
    <Captions captions={captions} />
  </AbsoluteFill>
);

// Same captions over a dark background — for previewing the effect with no video.
const CaptionDemo = ({captions}) => (
  <AbsoluteFill style={{backgroundColor: '#0B0B0C'}}>
    <Captions captions={captions} />
  </AbsoluteFill>
);

export const RemotionRoot = () => {
  return (
    <>
      <Composition
        id="CaptionedVideo"
        component={CaptionedVideo}
        durationInFrames={durationFrames(captions)}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{captions}}
      />
      <Composition
        id="CaptionDemo"
        component={CaptionDemo}
        durationInFrames={durationFrames(captions)}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{captions}}
      />
    </>
  );
};
