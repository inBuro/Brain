// Local, offline word-level transcription via whisper.cpp (no API keys).
// Usage:
//   1) put your exported video at public/video.mp4
//   2) extract 16kHz mono wav:
//        ffmpeg -i public/video.mp4 -ar 16000 -ac 1 -c:a pcm_s16le public/audio.wav
//   3) node transcribe.mjs
// It writes word-level timings to src/captions.json.

import path from 'path';
import fs from 'fs';
import {
  installWhisperCpp,
  downloadWhisperModel,
  transcribe,
  toCaptions,
} from '@remotion/install-whisper-cpp';

const MODEL = process.env.WHISPER_MODEL || 'medium'; // 'medium' handles Russian well; 'large-v3-turbo' is better/heavier
const WHISPER_VERSION = '1.5.5';
const to = path.join(process.cwd(), 'whisper.cpp');
const audio = path.join(process.cwd(), 'public', 'audio.wav');

if (!fs.existsSync(audio)) {
  console.error(
    'Missing public/audio.wav. First run:\n' +
      '  ffmpeg -i public/video.mp4 -ar 16000 -ac 1 -c:a pcm_s16le public/audio.wav'
  );
  process.exit(1);
}

await installWhisperCpp({to, version: WHISPER_VERSION});
await downloadWhisperModel({folder: to, model: MODEL});

const {transcription} = await transcribe({
  inputPath: audio,
  whisperPath: to,
  model: MODEL,
  tokenLevelTimestamps: true,
});

const {captions} = toCaptions({whisperCppOutput: transcription});

// Keep only real words with timings, in the shape the renderer expects.
const words = captions
  .filter((c) => c.text && c.text.trim().length && c.endMs > c.startMs)
  .map((c) => ({text: c.text.trim(), startMs: c.startMs, endMs: c.endMs}));

fs.writeFileSync(
  path.join(process.cwd(), 'src', 'captions.json'),
  JSON.stringify(words, null, 2)
);
console.log(`Wrote src/captions.json with ${words.length} words.`);
