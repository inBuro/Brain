# shorts-captions — premium word-by-word captions (Remotion)

Burns clean, premium captions onto a vertical video: the whole line is visible, every
word is **light gray**, and only the **currently spoken word turns white** with a subtle
scale-up + fade. No bounce, no emoji, no meme effects. Apple / Linear register.

The look lives in `src/Captions.jsx` — four values at the top control everything:
`COLOR_INACTIVE`, `COLOR_ACTIVE`, `ACTIVE_SCALE`, `FONT_SIZE`.

## One-time setup

```bash
npm install            # needs Node 18+ (install from nodejs.org if you don't have it)
```

## Preview the effect right now (no video needed)

```bash
npm run dev            # opens Remotion Studio; open the "CaptionDemo" composition
```

`CaptionDemo` plays the sample sentence in `src/captions.json` over a dark background so
you can dial in the style.

## Use it on your real Short

1. Export your finished Short from DaVinci Resolve and drop it in as `public/video.mp4`.
2. Extract 16 kHz mono audio and transcribe to word-level timings (fully local, no API):
   ```bash
   ffmpeg -i public/video.mp4 -ar 16000 -ac 1 -c:a pcm_s16le public/audio.wav
   npm run transcribe      # writes src/captions.json (whisper.cpp, model = medium)
   ```
   For better Russian accuracy: `WHISPER_MODEL=large-v3-turbo npm run transcribe`.
3. Preview: `npm run dev` → open the **CaptionedVideo** composition (captions over your video).
4. Render the final MP4:
   ```bash
   npm run render          # -> out/video.mp4
   ```

## Tweaking the style

Open `src/Captions.jsx`:
- `COLOR_INACTIVE` — the gray for non-active words (default `#B7BBC2`).
- `COLOR_ACTIVE` — the active word color (default `#FFFFFF`).
- `ACTIVE_SCALE` — subtle pop; `1` disables it, `1.06` is a gentle default.
- `FONT_SIZE`, font weight, `letterSpacing`, `bottomOffset` (vertical position) are next to it.
- Words per line: `maxWords` prop on `<Captions>` (default 5).
- Font: currently Inter (via `@remotion/google-fonts`). Swap to any Google font, or load a
  local font (e.g. SF Pro) for the exact Apple feel.

## Notes
- Manual fixes: edit `src/captions.json` directly if a word's timing or spelling is off.
- Remotion is free for individuals / companies ≤ 3 people (commercial use included).
- Alternative transcription: OpenAI `whisper-1` (word timestamps), Deepgram, or AssemblyAI —
  just produce `src/captions.json` as `[{ "text", "startMs", "endMs" }]`.
